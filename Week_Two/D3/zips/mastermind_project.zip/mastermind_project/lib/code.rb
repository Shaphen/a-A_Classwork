class Code
  attr_reader :pegs

  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  def self.valid_pegs? (arr)
    arr.all? { |ele| POSSIBLE_PEGS.has_key?(ele.upcase) }
  end

  def self.random (length)
    new_pegs = []
    while new_pegs.length < length
      new_pegs << POSSIBLE_PEGS.keys.sample
    end
    Code.new(new_pegs)
  end

  # iterate through str, from that check possible_pegs of str char, return the corresponding value
  # depending on char

  def self.from_string(str) #str represents pegs
    Code.new(str.chars)
  end

  def initialize (chars) #representing pegs
    if !Code.valid_pegs?(chars)
      raise 'error'
    else
      @pegs = chars.map { |ele| ele.upcase }  # set pegs array instance variable
    end
  end

  def [] (idx)
    @pegs[idx]
  end

  def length
    @pegs.length
  end

  def num_exact_matches (guess) #respresents a guess
    count = 0
    guess.pegs.each_with_index do |color, idx|
      if color == @pegs[idx]
        count += 1
      end
    end
    count
  end

  def num_near_matches (guess)
    count = 0
    guess.pegs.each_with_index do |color, idx|
      if color != @pegs[idx] && @pegs.include?(color)
        count += 1
      end
    end
    count
  end

  def == (other_guess)
    self.pegs == other_guess.pegs
  end

end
