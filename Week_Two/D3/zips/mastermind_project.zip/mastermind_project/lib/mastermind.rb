require_relative "code"

class Mastermind

    def initialize (length)
        @secret_code = Code.random(length)
    end

    def print_matches(guess)
        puts @secret_code.num_exact_matches(guess)
        puts @secret_code.num_near_matches(guess)
    end
    
    def ask_user_for_guess
        p 'Enter a code'
        user_guess = gets.chomp
        user_guess_instance = Code.from_string(user_guess)
        print_matches(user_guess_instance)
        @secret_code == user_guess_instance
    end
end
