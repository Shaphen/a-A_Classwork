class Board
    attr_reader :size

    def self.print_grid(grid)
        grid.each {|row| puts row.join(' ')}
    end

    def initialize (n)
        @grid = Array.new(n) {Array.new(n, :N)}
        @size = n ** 2
    end
    
    def [] (array) # array contains 2 elements, [row, column]
        @grid[array[0]][array[1]]
    end

    def []= (pos, val)
        @grid[pos[0]][pos[1]] = val
    end
    
    def num_ships
        count = 0
        @grid.each do |subarr|
            subarr.each do |ele|
                if ele == :S
                    count += 1
                end
            end
        end
        count
    end

    def attack (pos)
        if self[pos] == :S
            self[pos] = :H
            p 'You sunk my battleship!'
            return true
        else
            self[pos] = :X
            return false
        end
    end

    def place_random_ships
        num_times = @size / 4
        x_pos = 0
        y_pos = 0
        while self.num_ships < num_times
            x_pos = rand(@grid.length) - 1
            y_pos = rand(@grid.length) - 1
            pos = [x_pos, y_pos]
            self[pos] = :S
        end
    end

    def hidden_ships_grid
        @grid.map.with_index do |subarr, idx1|
            subarr.map.with_index do |ele, idx2|
                if ele == :S
                    :N
                else
                    ele
                end
            end
        end
    end

    def cheat
        Board.print_grid(@grid)
    end

    def print
        Board.print_grid(hidden_ships_grid)
    end
    
end
